"""AI 상담·롤플레잉·문장 다듬기 실제 함수. 백엔드 app/llm_client.py 가 LLM_MODE=real 일 때 쓴다.

함수 형식은 목 함수(backend/app/llm_mock.py)와 같다. 백엔드는 예외·형식 오류를 503 AI_UNAVAILABLE 로 바꾼다.
- 대화 내용은 로그·예외 메시지에 넣지 않는다 (api.md 1.6). 이름·전화번호·생년월일은 받지 않는다.
- 상담 답변에 금액이나 자격 단정이 들어가면 고정 안내 문장으로 바꾼다 (계획서 7.3).
- 테스트는 generate 인자로 가짜 LLM 을 넣는다.
"""

import json
import re
from collections.abc import Callable, Iterable, Iterator

from coach.prompts import (
    COUNSEL_SYSTEM, INTENT_SYSTEM, LEVEL_GUIDE, POLISH_SYSTEM, ROLEPLAY_SYSTEM, STAGE_STYLE,
)
from rag.guard import has_assertion

# messages → JSON dict
Generate = Callable[[list[dict]], dict]
# messages → 글 조각 (스트리밍)
TextStream = Callable[[list[dict]], Iterator[str]]

# LLM 에 넘기는 앞 대화 수 (오래된 것부터 버림)
HISTORY_TURNS = 10
# 롤플레잉은 통화 전체를 봐야 같은 말을 되풀이하지 않는다
ROLEPLAY_HISTORY_TURNS = 40
# 앞서 한 말과 낱말이 이만큼 겹치면 되풀이로 본다
REPEAT_OVERLAP = 0.7
_WORD = re.compile(r"[가-힣A-Za-z0-9]{2,}")
# 상대 역할이 대사 흐름보다 이만큼 더 말하면 마무리한다 (대화가 끝없이 이어지는 것만 막는다)
ROLEPLAY_EXTRA_TURNS = 10
# 사용자가 대화를 끝내려는 말 (이 말이 있을 때만 LLM 의 마무리를 받아들인다)
# 끝맺는 말. 확실한 말은 언제든, 대답에도 쓰이는 말("알겠습니다")은 대사 흐름을 거의 다 했을 때만 끝으로 본다
_CLOSING_WORDS = ("감사합니다", "고맙습니다", "감사해요", "고마워요", "안녕히", "수고하세요", "수고하셨", "끊을게", "끊겠습니다",
                  "들어가세요", "그럼이만", "이만할게", "이만갈게", "가볼게요", "가보겠습니다")
_SOFT_CLOSING_WORDS = ("됐어요", "됐습니다", "알겠습니다", "알겠어요", "그렇게할게요", "그럴게요", "네그럼", "좋아요그럼")
# 상대가 앞 차례에 마무리 인사를 했고 사용자가 짧게 "네"로 받으면 끝 (상대가 혼자 끝내지는 않는다)
_FAREWELL_WORDS = ("안녕히", "조심히", "좋은하루", "들어가세요", "또오세요", "수고하세요", "다음에뵐게요", "끊을게요")
_ACK_WORDS = ("네", "넵", "네네", "예", "네알겠습니다", "네감사합니다", "넹")
ROLEPLAY_NEAR_END = 1  # 대사 흐름이 이만큼 남았을 때부터 '알겠습니다' 같은 말도 끝맺음으로 본다

SAFE_COUNSEL = (
    "이야기해 줘서 고마워요. 지원 제도의 금액이나 받을 수 있는지는 정책 찾기에서 물어보면 공식 자료로 알려 줄게요. "
    "지금 마음이나 상황을 조금 더 이야기해 줄래요?"
)
ROLEPLAY_END = "네, 오늘은 여기까지 할게요. 수고했어요."

_MONEY_RE = re.compile(r"\d[\d,]*\s*(만\s*)?원")
# 자주 섞이는 반말 끝말 → 해요체 (뜻은 그대로). 문장 끝에서만 바꾼다
_CASUAL_ENDINGS = ((r"구나", "군요"), (r"어때", "어때요"), (r"해 봐", "해 봐요"), (r"볼까", "볼까요"), (r"있어", "있어요"))
_STATUS_TEXT = {"in_care": "보호 중", "leaving_soon": "퇴소 예정", "left_care": "퇴소함"}


class CoachFormatError(RuntimeError):
    pass


# JSON 이 아닌 출력이 오면 다시 요청하는 횟수
JSON_RETRIES = 1


def _openai_generate(messages: list[dict], temperature: float = 0.4, quick: bool = False) -> dict:
    """quick: 답이 짧은 판단 (짧게 기다리고 바로 다시 요청)"""
    from rag.openai_client import _client, quick_client
    from rag.settings import get_rag_settings

    client = quick_client() if quick else _client()
    for _ in range(1 + JSON_RETRIES):
        resp = client.chat.completions.create(
            model=get_rag_settings().coach_model, temperature=temperature, max_tokens=500,
            response_format={"type": "json_object"}, messages=messages,
        )
        try:
            return json.loads(resp.choices[0].message.content or "")
        except json.JSONDecodeError:
            continue
    raise CoachFormatError("LLM 출력이 JSON 이 아닙니다.")  # 원문(대화 포함 가능)은 넣지 않는다


def _words(text: str) -> set[str]:
    return set(_WORD.findall(text))


def repeats(reply: str, said: list[str]) -> bool:
    """앞서 상대 역할이 한 말을 거의 그대로 다시 하는지 (낱말 70% 이상 겹침)"""
    w = _words(reply)
    if len(w) < 3:
        return False
    return any(len(w & _words(x)) / len(w) >= REPEAT_OVERLAP for x in said)


def _done_lines(lines: list[str], said: list[str]) -> set[int]:
    """대사 흐름 중 상대 역할이 이미 꺼낸 것 (낱말 절반 이상 겹침)"""
    out = set()
    for i, line in enumerate(lines):
        w = _words(line)
        if w and any(len(w & _words(x)) / len(w) >= 0.5 for x in said):
            out.add(i)
    return out


def _history(history: list[dict], limit: int = HISTORY_TURNS) -> list[dict]:
    turns = [h for h in history if h.get("role") in ("user", "assistant") and str(h.get("content") or "").strip()]
    return [{"role": h["role"], "content": str(h["content"])} for h in turns[-limit:]]


def _text(v: object) -> str:
    return v.strip() if isinstance(v, str) else ""


def classify_intent(message: str, history: list[dict], generate: Generate | None = None) -> str:
    out = (generate or (lambda m: _openai_generate(m, quick=True)))([
        {"role": "system", "content": INTENT_SYSTEM},
        *_history(history)[-4:],
        {"role": "user", "content": message},
    ])
    intent = out.get("intent") if isinstance(out, dict) else None
    return intent if intent in ("policy", "counsel") else "counsel"


def _context(profile: dict) -> str:
    lines = []
    if profile.get("status") in _STATUS_TEXT:
        lines.append(f"상태: {_STATUS_TEXT[profile['status']]}")
    d_day = profile.get("d_day")
    if isinstance(d_day, int) and d_day >= 0:
        lines.append(f"퇴소·목표일까지 {d_day}일")
    if not lines:
        return ""
    return "\n[사용자 상황] " + ", ".join(lines) + " (필요할 때만 자연스럽게 참고하고, 먼저 꺼내지 않는다)\n"


def polite(text: str) -> str:
    """문장 끝 반말("~구나", "~어때?")을 해요체로 바꾼다."""
    for casual, formal in _CASUAL_ENDINGS:
        text = re.sub(rf"{casual}(?=[.!?]|$)", formal, text)
    return text


def safe_counsel(reply: str) -> str:
    """금액이나 자격 단정이 들어간 답변은 고정 안내로 바꾸고, 반말 끝말은 해요체로 고친다."""
    if _MONEY_RE.search(reply) or has_assertion(reply):
        return SAFE_COUNSEL
    return polite(reply)


def counsel_reply(message: str, history: list[dict], profile: dict, generate: Generate | None = None) -> str:
    stage = profile.get("stage") if profile.get("stage") in STAGE_STYLE else "youth"
    out = (generate or _openai_generate)([
        {"role": "system", "content": COUNSEL_SYSTEM.format(style=STAGE_STYLE[stage], context=_context(profile))},
        *_history(history),
        {"role": "user", "content": message},
    ])
    reply = _text(out.get("reply") if isinstance(out, dict) else None)
    if not reply:
        raise CoachFormatError("상담 답변이 비어 있습니다.")
    return safe_counsel(reply)


def _situation(scenario: dict) -> str:
    text = _text(scenario.get("situation"))
    return f"[이번 전개] {text} 이 전개대로 반응한다.\n" if text else ""


def _surprises(scenario: dict) -> str:
    """돌발 상황: 대사 흐름에 이미 끼워 두었다. 꼭 한 번씩 꺼내고, 사용자의 대처에 따라 반응하게 한다"""
    items = [_text(x) for x in scenario.get("surprises") or [] if _text(x)]
    if not items:
        return ""
    listed = "\n".join(f"- {x}" for x in items)
    return (
        "[돌발 상황] 대화가 어느 정도 이어진 뒤, 아래 말을 한 번씩 꺼낸다.\n"
        "- 갑자기 툭 던지지 말고 앞 대화에서 자연스럽게 이어지게 꺼낸다 (예: \"아 그런데요,\", \"참, 말 나온 김에\" 처럼 운을 떼고).\n"
        "- 지금까지 대화에서 정해진 사실(누가 소리를 냈는지, 무엇을 하러 왔는지 등)과 어긋나면 그 사실에 맞게 바꿔 말하고, "
        "도저히 맞지 않으면 꺼내지 않는다.\n"
        "- 사용자가 분명하게 대처하면 받아들이고, 얼버무리면 한 번 더 확인한다.\n"
        f"{listed}\n"
    )


# 음성 인식 글은 문장부호가 없다. 질문으로 보이면 (질문) 을 붙여 상대 역할이 질문에 먼저 답하게 한다
_ASK_WORDS = re.compile(r"(뭐|무엇|무슨|언제|어디|얼마|몇|왜|어떻게|어떤|누구|어느)")
_ASK_ENDINGS = re.compile(r"(나요|까요|까|는지요|는지|죠|지요|니|냐|어때요|어때)$")
_STATEMENT_ENDINGS = re.compile(r"(주세요|드려요|드릴게요|게요|했어요|됐어요|왔어요|싶어요|합니다|습니다)$")


def looks_question(text: str) -> bool:
    """음성 인식 글(문장부호 없음)이 질문 같은지. 문장부호가 있으면 그대로 따른다"""
    t = text.strip()
    if not t:
        return False
    if t.endswith("?"):
        return True
    if t.endswith((".", "!")):
        return False
    tail = t.split()[-1]
    if _STATEMENT_ENDINGS.search(tail):
        return False
    if _ASK_ENDINGS.search(tail):
        return True
    # "~요" 로 끝나도 의문사가 있으면 질문 ("보증금 얼마예요", "언제 와요")
    return tail.endswith("요") and bool(_ASK_WORDS.search(t))


def voice_message(message: str) -> str:
    return f"{message} (질문)" if looks_question(message) and not message.strip().endswith("?") else message


class _RoleplayTurn:
    """롤플레잉 한 턴을 만들 재료 (보통 답변 · 스트리밍 답변이 같이 쓴다)"""

    def __init__(self, scenario: dict, history: list[dict], message: str) -> None:
        self.message = message
        self.lines = [str(x) for x in scenario.get("lines") or []]
        self.spoken = sum(1 for h in history if h.get("role") == "assistant")
        self.said = [str(h.get("content") or "") for h in history if h.get("role") == "assistant"]
        # 상대가 너무 오래 말했으면 AI 에게 묻지 않고 끝낸다
        self.over = self.spoken >= len(self.lines) + ROLEPLAY_EXTRA_TURNS
        self.messages = [] if self.over else _roleplay_messages(scenario, history, message, self.lines, self.said)

    def retry_messages(self, out: dict) -> list[dict]:
        return self.messages + [
            {"role": "assistant", "content": json.dumps(out, ensure_ascii=False)},
            {"role": "system", "content": "방금 답은 앞에서 이미 한 말과 거의 같다. 같은 말을 되풀이하지 말고, 사용자의 마지막 말에 맞는 새 말로 다시 답한다."},
        ]

    def finished(self, llm_flag: bool) -> bool:
        """상대 역할이 혼자 대화를 끝내지 않게: 질문이 아니고, 사용자가 끝맺는 말을 했거나 대사 흐름을 다 했을 때만 받아들인다"""
        message, said, lines, spoken = self.message, self.said, self.lines, self.spoken
        flat = re.sub(r"\s+", "", message)
        near_end = spoken + 1 >= len(lines) - ROLEPLAY_NEAR_END
        closing = any(w in flat for w in _CLOSING_WORDS) or (near_end and any(w in flat for w in _SOFT_CLOSING_WORDS))
        # 질문 중에는 끝내지 않는다. 사용자가 끝맺었을 때만 AI 판단을 받아들인다
        llm_done = llm_flag and closing and not looks_question(message)
        # 상대가 바로 앞에서 마무리 인사를 했고 사용자가 "네"로 받으면 AI 판단과 상관없이 끝
        last_partner = re.sub(r"\s+", "", said[-1]) if said else ""
        acked = any(w in last_partner for w in _FAREWELL_WORDS) and re.sub(r"[\s.!~]+", "", message) in _ACK_WORDS
        return llm_done or acked or spoken + 1 >= len(lines) + ROLEPLAY_EXTRA_TURNS


def _roleplay_messages(scenario: dict, history: list[dict], message: str, lines: list[str], said: list[str]) -> list[dict]:
    done = _done_lines(lines, said)
    system = ROLEPLAY_SYSTEM.format(
        partner=scenario.get("partner") or "상대",
        setting=scenario.get("setting") or "",
        goal=scenario.get("goal") or "",
        level_guide=LEVEL_GUIDE.get(str(scenario.get("level")), LEVEL_GUIDE["NORMAL"]),
        situation=_situation(scenario),
        surprises=_surprises(scenario),
        lines="\n".join(
            f"{i}. {x}" + (" (이미 함, 다시 말하지 않음)" if i - 1 in done else "") for i, x in enumerate(lines, 1)
        ) or "(없음)",
    )
    # 앞 대화의 사용자 말에도 같은 표시를 붙인다 (앞에서 무엇을 물었는지 알게)
    turns = [
        {**h, "content": voice_message(h["content"])} if h["role"] == "user" else h
        for h in _history(history, ROLEPLAY_HISTORY_TURNS)
    ]
    return [{"role": "system", "content": system}, *turns, {"role": "user", "content": voice_message(message)}]


def roleplay_reply(scenario: dict, history: list[dict], message: str, generate: Generate | None = None) -> dict:
    """history 첫 대사(상대 역할의 첫마디)는 백엔드가 넣어 둔다."""
    t = _RoleplayTurn(scenario, history, message)
    if t.over:
        return {"reply": ROLEPLAY_END, "is_finished": True}
    # 사람처럼 말하게 하되, 엉뚱한 말은 프롬프트 규칙으로 막는다
    out = generate(t.messages) if generate else _openai_generate(t.messages, temperature=0.5)
    reply = _text(out.get("reply") if isinstance(out, dict) else None)
    # 앞서 한 말을 되풀이하면 한 번만 다시 요청한다
    if reply and repeats(reply, t.said):
        again = t.retry_messages(out)
        retry = generate(again) if generate else _openai_generate(again, temperature=0.5)
        new = _text(retry.get("reply") if isinstance(retry, dict) else None)
        if new and not repeats(new, t.said):
            out, reply = retry, new
    if not reply:
        raise CoachFormatError("롤플레잉 답변이 비어 있습니다.")
    return {"reply": reply, "is_finished": t.finished(out.get("is_finished") is True)}


def polish_sentences(doc_type: str, sentences: list[str], generate: Generate | None = None) -> list[str]:
    """문장 수가 달라지거나 형식이 틀리면 원래 문장을 그대로 돌려준다 (뜻이 바뀌는 것보다 안전)."""
    if not sentences:
        return []
    out = (generate or _openai_generate)([
        {"role": "system", "content": POLISH_SYSTEM.format(doc_type=doc_type or "서류")},
        {"role": "user", "content": json.dumps({"sentences": sentences}, ensure_ascii=False)},
    ])
    polished = out.get("sentences") if isinstance(out, dict) else None
    if not isinstance(polished, list) or len(polished) != len(sentences) or not all(_text(s) for s in polished):
        return list(sentences)
    return [_text(s) for s in polished]


JUDGE_SYSTEM = """너는 말하기 연습의 채점자다. 사용자가 통화·면접·창구 상황에서 한 말을 보고,
아래 '챙길 것' 각각을 사용자가 실제로 말했는지 뜻으로 판단한다.

규칙:
- 사용자가 한 말에 그 내용이 분명히 들어 있을 때만 챙겼다고 본다. 비슷한 뜻·다른 표현·사투리·구어체도 인정한다.
- 음성 인식 글이라 띄어쓰기·맞춤법·물음표가 틀리거나 빠질 수 있다. 소리가 비슷한 오타는 뜻으로 읽는다.
- 대화에는 상대 말도 있다. 상대가 한 말은 사용자가 챙긴 것이 아니다. 사용자 말만 보고 판단하되, 앞뒤 상대 말로 뜻을 읽는다.
- 항목 이름이 '묻기 · 물어보기 · 확인'이면 그것을 물어본 것도 챙긴 것이다.
- 그 밖의 항목(챙기기 · 준비 · 말하기 · 정하기 · 거절하기 …)은 사용자가 실제로 그렇게 말하거나 행동했을 때만 챙긴 것이다.
  상대가 한 말을 되묻기만 한 것("임대차 계약서요?", "신분증이요?"), 그게 뭔지 물어본 것, "없어요 · 안 가져왔어요"는 챙긴 것이 아니다.
  예: 상대 "임대차 계약서 가져오셨어요?" → 사용자 "임대차 계약서요?" = 안 챙김 / 사용자 "네 여기 임대차 계약서요" = 챙김
- 애매하면 챙기지 않은 것으로 본다.

JSON 으로만 답한다: {"done": ["챙긴 항목 label 그대로", ...]}"""


def judge_checks(
    checks: list[dict], user_turns: list[str], generate: Generate | None = None, history: list[dict] | None = None,
) -> list[str]:
    """checks: [{"label", "example"}]. 사용자가 뜻으로 챙긴 label 목록 (주어진 label 중에서만).
    history: [{"role": "user"|"assistant", "content"}] 가 있으면 상대 말과 함께 본다 (되묻기 · 질문 구분)"""
    labels = [str(c.get("label") or "") for c in checks if c.get("label")]
    said = [t.strip() for t in user_turns if t and t.strip()]
    if not labels or not said:
        return []
    items = "\n".join(
        f"- label: {c['label']}" + (f" (예: {c['example']})" if c.get("example") else "") for c in checks if c.get("label")
    )
    if history:
        lines = [h for h in history if h.get("role") in ("user", "assistant") and str(h.get("content") or "").strip()]
        talk = "\n".join(
            f"{'사용자' if h['role'] == 'user' else '상대'}: {str(h['content']).strip()}"
            for h in lines[-ROLEPLAY_HISTORY_TURNS * 2:]
        )
        body = f"챙길 것:\n{items}\n\n대화 (사용자 말만 판단):\n{talk}"
    else:
        talk = "\n".join(f"{i}. {t}" for i, t in enumerate(said[-ROLEPLAY_HISTORY_TURNS:], 1))
        body = f"챙길 것:\n{items}\n\n사용자가 한 말:\n{talk}"
    messages = [{"role": "system", "content": JUDGE_SYSTEM}, {"role": "user", "content": body}]
    out = generate(messages) if generate else _openai_generate(messages, temperature=0, quick=True)
    done = out.get("done") if isinstance(out, dict) else None
    if not isinstance(done, list):
        raise CoachFormatError("판정 형식이 아닙니다.")
    return [x for x in done if isinstance(x, str) and x in labels]


# ---------------- 스트리밍 (만들어지는 대로 한 문장씩) ----------------
# 답을 다 만들 때까지 기다리지 않고 문장이 끝날 때마다 보낸다 → 첫 문장이 1초 안에 보이고, 음성은 바로 읽기 시작한다.
# 금액·자격 단정 검사와 해요체 고치기는 문장마다 한다.

COUNSEL_TEXT_OUTPUT = "출력: JSON 없이 답변 글만 쓴다. 머리말·따옴표 없이 바로 말한다."
ROLEPLAY_END_MARK = "[끝]"
ROLEPLAY_TEXT_OUTPUT = (
    "출력: JSON 없이 상대 역할이 할 말만 쓴다 (이름·따옴표·설명 없이). "
    f'6번처럼 대화를 마무리하는 차례면("is_finished": true 인 경우) 말 맨 끝에 {ROLEPLAY_END_MARK} 를 붙인다.'
)
# 문장 끝: 마침표·물음표·느낌표(뒤에 따옴표·괄호가 와도) 다음 띄어쓰기, 또는 줄바꿈
_SENTENCE_END = re.compile(r"[.!?…]+[\"'”’)\]]*\s+|\n+")


def _text_output(system: str, line: str) -> str:
    """JSON 출력 지시(마지막 '출력:' 줄)를 글로 쓰라는 지시로 바꾼다"""
    i = system.rfind("출력:")
    return (system[:i] if i >= 0 else system + "\n") + line


def _openai_stream(messages: list[dict], temperature: float = 0.4) -> Iterator[str]:
    from rag.openai_client import stream_client
    from rag.settings import get_rag_settings

    resp = stream_client().chat.completions.create(
        model=get_rag_settings().coach_model, temperature=temperature, max_tokens=500, messages=messages, stream=True,
    )
    for chunk in resp:
        if chunk.choices:
            piece = chunk.choices[0].delta.content
            if piece:
                yield piece


def sentences(pieces: Iterable[str]) -> Iterator[str]:
    """글 조각을 문장 단위로 모은다. 소수점(1.5)처럼 뒤에 띄어쓰기가 없는 점에서는 자르지 않는다"""
    buf = ""
    for piece in pieces:
        buf += piece
        while (m := _SENTENCE_END.search(buf)) is not None:
            sentence, buf = buf[: m.end()].strip(), buf[m.end():]
            if sentence:
                yield sentence
    if buf.strip():
        yield buf.strip()


def counsel_stream(message: str, history: list[dict], profile: dict, stream: TextStream | None = None) -> Iterator[dict]:
    """{"delta": 문장} 을 차례로, 마지막에 {"final": 전체 답, "replace": bool}.
    금액·자격 단정 문장이 나오면 거기서 멈추고 고정 안내로 바꾼다 (replace=True: 앞에 보인 문장도 바꿔야 함)"""
    stage = profile.get("stage") if profile.get("stage") in STAGE_STYLE else "youth"
    system = _text_output(COUNSEL_SYSTEM.format(style=STAGE_STYLE[stage], context=_context(profile)), COUNSEL_TEXT_OUTPUT)
    messages = [{"role": "system", "content": system}, *_history(history), {"role": "user", "content": message}]
    parts: list[str] = []
    for s in sentences((stream or _openai_stream)(messages)):
        if _MONEY_RE.search(s) or has_assertion(s):
            yield {"final": SAFE_COUNSEL, "replace": True}
            return
        s = polite(s)
        parts.append(s)
        yield {"delta": s}
    if not parts:
        raise CoachFormatError("상담 답변이 비어 있습니다.")
    yield {"final": " ".join(parts), "replace": False}


def roleplay_stream(
    scenario: dict, history: list[dict], message: str,
    stream: TextStream | None = None, generate: Generate | None = None,
) -> Iterator[dict]:
    """{"delta": 문장} 을 차례로, 마지막에 {"final": 전체 대사, "is_finished": bool, "replace": bool}.
    앞서 한 말을 되풀이했으면 한 번 다시 받아 replace=True 로 바꾼다 (드묾)"""
    t = _RoleplayTurn(scenario, history, message)
    if t.over:
        yield {"delta": ROLEPLAY_END}
        yield {"final": ROLEPLAY_END, "is_finished": True, "replace": False}
        return
    system = _text_output(t.messages[0]["content"], ROLEPLAY_TEXT_OUTPUT)
    messages = [{"role": "system", "content": system}, *t.messages[1:]]
    run = stream or (lambda m: _openai_stream(m, temperature=0.5))
    parts: list[str] = []
    flag = False
    for s in sentences(run(messages)):
        if ROLEPLAY_END_MARK in s:
            flag = True
            s = s.replace(ROLEPLAY_END_MARK, "").strip()
        if s:
            parts.append(s)
            yield {"delta": s}
    reply = " ".join(parts)
    if not reply:
        raise CoachFormatError("롤플레잉 답변이 비어 있습니다.")
    replace = False
    if repeats(reply, t.said):
        again = t.retry_messages({"reply": reply, "is_finished": flag})
        try:
            retry = generate(again) if generate else _openai_generate(again, temperature=0.5)
        except Exception:
            retry = None  # 다시 받기가 안 되면 처음 답 그대로
        new = _text(retry.get("reply") if isinstance(retry, dict) else None)
        if new and not repeats(new, t.said):
            reply, flag, replace = new, retry.get("is_finished") is True, True
    yield {"final": reply, "is_finished": t.finished(flag), "replace": replace}
