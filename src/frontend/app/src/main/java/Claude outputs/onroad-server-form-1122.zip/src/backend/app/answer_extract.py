"""대화로 채우기: 사용자 말에서 칸에 넣을 답만 뽑는다 (docs/document-ai.md 3.32).

칸 종류마다 형식을 보고 답을 찾는다. 못 찾으면 None → 다시 묻는다 (아무 말이나 그대로 적지 않는다).
- 이름·주소·이메일·등록번호처럼 개인정보가 들어가는 칸은 규칙으로만 뽑는다 (LLM 에 보내지 않음, api.md 1.6)
- 기관명·관계·은행 같은 일반 칸은 짧은 답이면 그대로, 대화 문장이면 LLM(extract_answer)이 답만 뽑고 확인을 받는다

kind: name / address / email / bizno / text
"""

import re

from app.codes import USER_REGIONS
from app.profile_signal import name_in

# 답 끝의 말버릇 (예: "정서현이에요", "부산이요", "OO아동복지원입니다")
_TAIL_RE = re.compile(
    r"\s*(이라고\s*해요|라고\s*해요|이라고\s*합니다|라고\s*합니다|이에요|예요|이요|입니다|이야|이고요|이구요|요|야|임)[.!~]*$"
)
_LEAD_RE = re.compile(r"^(?:(?:제|저는|전|나는|난|내|우리|저희)\s*|(?:저|나)\s+)")
_HANGUL_NAME_RE = re.compile(r"^[가-힣]{2,4}$")
_LATIN_NAME_RE = re.compile(r"^[A-Za-z][A-Za-z .'-]{1,40}$")
# "이름은 정서현", "성명: 정서현", "정서현이에요", "저는 정서현"
_NAME_PATTERNS = (
    # "이름은 김민지고 2006년생" 처럼 이어 말해도 이름만 ("고·이고·이구·구·랑·이랑" 떼기)
    re.compile(r"(?:이름|성함|성명)\s*(?:은|는|이|:)?\s*([가-힣]{2,5}?)(?:이에요|예요|입니다|이야|야|이요|요|이고|고|이구|구|이랑|랑|이라고|라고)?(?=$|[\s.,!?~])"),
    re.compile(r"(?:저는|전|나는|난|저|나)\s+([가-힣]{2,5}?)(?:이에요|예요|입니다|이야|야|이요|요|이고|고|이라고|라고)(?=$|[\s.,!?~])"),
)
_NOT_NAME = {"이름", "성명", "모르", "몰라", "없어", "없음", "비밀", "그거", "뭐야", "누구", "아무거나", "그냥", "글쎄", "싫어"}
_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
_DIGITS_RE = re.compile(r"\d+")
# 주소에 들어가는 말: 시·도·구·군·읍·면·동·리·로·길·번지·호 또는 숫자
_ADDRESS_TOKEN_RE = re.compile(r"[가-힣0-9]+(?:특별시|광역시|특별자치시|특별자치도|시|도|구|군|읍|면|동|리|로|길|번길|번지|호)(?=\s|$|,|\d)")
_ADDRESS_TAIL_RE = re.compile(r"\s*(?:에서?\s*)?(살아요|살아|살고\s*있어요|살고\s*있어|삽니다|이에요|예요|입니다|이요|요)[.!~]*$")


def kind_of(spec: dict) -> str:
    label = "".join(spec["label"].split()).rstrip(":*")
    low = label.lower()
    if spec.get("input_type") == "address" or label.endswith("주소"):
        return "address"
    if "mail" in low or "이메일" in label:
        return "email"
    if "사업자등록번호" in label or "고유번호" in label:
        return "bizno"
    if spec.get("profile_key") == "name" or label.endswith(("성명", "이름", "예금주", "대표자명", "대표자명(위탁부모)")):
        return "name"
    return "text"


# "~(으)로 해 줘", "~(이)라고 써 주세요", "~로 바꿔줘", "~로 할게요" 같은 부탁 말끝
_REQUEST_RE = re.compile(
    r"\s*(?:해|써|적어|바꿔|넣어|고쳐|변경해|수정해|입력해|할게|할께|하자|하면\s*돼|하면\s*되)"
    r"\s*(?:줘|주세요|줄래|주라|줘요|주실래요|요|봐)?[.!~]*$"
)
_PARTICLE_RE = re.compile(r"\s*(으로|로|이라고|라고|이랑|랑|이고|이요|으로요|로요)$")


def _has_batchim(ch: str) -> bool:
    code = ord(ch) - 0xAC00
    return 0 <= code < 11172 and code % 28 != 0


def _strip_particle(text: str) -> str:
    """끝의 조사만 뗀다. 받침에 맞을 때만 ("정서현으로"→정서현, "김민지로"→김민지, "OO로"는 그대로)"""
    m = _PARTICLE_RE.search(text)
    if m is None:
        return text
    head, p = text[: m.start()].rstrip(), m.group(1)
    if len(head) < 2 or not ("가" <= head[-1] <= "힣"):
        return text
    batchim = _has_batchim(head[-1])
    if p.startswith(("으로", "이라고", "이랑", "이고", "이요")) and not batchim:
        return text
    if p in ("로", "로요", "라고", "랑") and batchim and not head.endswith("ㄹ"):
        # 받침 뒤 '로'는 ㄹ 받침일 때만 ("서울로"), 나머지는 칸 값의 일부일 수 있어 그대로
        if (ord(head[-1]) - 0xAC00) % 28 != 8:
            return text
    return head


# 동사·형용사로 끝난 말 ("일했어요", "없어요", "좋아해요"). 서류 문장이라 '요'를 떼면 반말이 된다
_VERB_END_RE = re.compile(r"(?:어요|아요|여요|해요|워요|와요|네요|게요|래요|대요|세요|셔요|죠|지요|까요|나요|군요|습니다|ㅂ니다)[.!~]*$")


def strip_tail_text(text: str) -> str:
    """일반 글 칸: 부탁 말끝만 떼고, 동사로 끝난 문장은 존댓말 그대로 둔다 ("일했어요" → 일했어요)"""
    t = _REQUEST_RE.sub("", text.strip()).strip()
    if _VERB_END_RE.search(t):
        return t.rstrip(".!~ ") or text.strip()
    return strip_tail(t)


def strip_tail(text: str) -> str:
    """말끝·부탁·조사를 떼고 칸 값만 ("정서현으로 해 줘"→정서현, "OO복지원이에요"→OO복지원)"""
    t = text.strip()
    for _ in range(3):
        before = t
        t = _REQUEST_RE.sub("", t).strip()
        t = _TAIL_RE.sub("", t).strip()
        t = _strip_particle(t).strip()
        if t == before:
            break
    return t or text.strip()


def _name(message: str) -> str | None:
    renamed = name_in(message)
    if renamed:
        return renamed
    plain = _LEAD_RE.sub("", strip_tail(message)).strip()
    plain = re.sub(r"^(?:이름|성함|성명)\s*(?:은|는|이|:)?\s*", "", plain).strip()
    if re.fullmatch(r"[가-힣]{1,2} [가-힣]{1,3}", plain) and len(plain) <= 5:
        plain = plain.replace(" ", "")  # "정 서현" → 정서현
    if re.fullmatch(r"[가-힣](?: [가-힣]){1,3}", plain):
        plain = plain.replace(" ", "")  # 한 글자씩 또박또박 "김 민 지" → 김민지
    if _HANGUL_NAME_RE.match(plain) and plain not in _NOT_NAME:
        return plain
    if _LATIN_NAME_RE.match(plain) and len(plain.split()) <= 3:
        return plain
    for regex in _NAME_PATTERNS:
        m = regex.search(message)
        if m and m.group(1) not in _NOT_NAME:
            return m.group(1)
    return None


def _address(message: str) -> str | None:
    text = message.strip()
    m = _ADDRESS_TOKEN_RE.search(text)
    if m is None:
        return None
    # 첫 주소 낱말(앞에 "부산"처럼 짧은 시·도 이름이 있으면 거기)부터 끝까지, 뒤의 "에 살아요" 같은 말은 뗀다
    start = m.start()
    regions = [r.start() for r in re.finditer("|".join(USER_REGIONS), text[: m.start()])]
    if regions:
        start = regions[-1]
    addr = _ADDRESS_TAIL_RE.sub("", text[start:]).strip(" .,~!")
    has_number = bool(_DIGITS_RE.search(addr))
    tokens = len(_ADDRESS_TOKEN_RE.findall(addr))
    return addr if (tokens >= 2 or has_number) else None


def _bizno(message: str) -> str | None:
    digits = "".join(_DIGITS_RE.findall(message))
    if len(digits) == 10:
        return f"{digits[:3]}-{digits[3:5]}-{digits[5:]}"
    return None


# 답이 아닌 짧은 말: 감탄·맞장구·거절·모름 (칸에 적지 않는다)
NO_WORDS = {"아니", "아니요", "아뇨", "아니야", "아니에요", "ㄴㄴ", "노", "no", "싫어", "싫어요", "안돼", "아니다"}
NOISE_WORDS = NO_WORDS | {
    "음", "음음", "어", "엥", "에", "응", "웅", "ㅇㅇ", "ㅇ", "네", "넵", "예", "글쎄", "글쎄요", "그냥", "몰라", "몰라요",
    "모름", "아무거나", "아무거나요", "뭐", "왜", "헐", "와", "오", "아", "흠", "ok", "오케이", "막", "진짜", "그래", "그래요",
    "됐어", "됐어요", "알았어", "알겠어", "알겠어요", "ㅋ", "ㅎ", "ㅠ", "ㅜ", "test", "테스트", "asdf",
    "알아서", "대충", "적당히", "아무렇게나", "아무렇게", "니가", "네가", "너가", "니맘대로", "맘대로", "마음대로",
}
_JAMO_RE = re.compile(r"^[ㄱ-ㅎㅏ-ㅣ.,!?~^\s]+$")


def is_noise(message: str) -> bool:
    """답이 아닌 말인지: 자음·모음만("ㅋㅋ", "ㅠㅠ"), 감탄·맞장구·거절("음", "아니", "막 아니"), 기호만"""
    text = message.strip().lower()
    if not text or _JAMO_RE.match(text) or not re.search(r"[가-힣A-Za-z0-9]", text):
        return True
    words = [re.sub(r"[.,!?~^]+$", "", w) for w in text.split()]
    return all(w in NOISE_WORDS or _JAMO_RE.match(w or "ㅋ") for w in words)


def is_no(message: str) -> bool:
    return re.sub(r"[\s.,!?~^]", "", message.strip().lower()) in NO_WORDS


# 칸과 상관없는 잡담 ("나 배고파", "졸려", "심심해"): 칸에 적지 않고, LLM 도 부르지 않는다
_SMALL_TALK = ("배고", "배불", "졸려", "졸리", "졸립", "피곤", "심심", "귀찮", "놀고싶", "놀래", "자고싶", "잘래", "밥먹",
               "밥뭐", "뭐먹", "뭐해", "안녕", "하이", "ㅎㅇ", "잘자", "고마워", "고맙", "감사해", "사랑해", "짜증", "지루")


def is_small_talk(message: str) -> bool:
    flat = re.sub(r"[\s.,!?~^]", "", message.strip().lower())
    return len(flat) <= 12 and any(w in flat for w in _SMALL_TALK)


# 문장(말하는 투)인지: 칸 답(명사)이 아니라 "나 배고파", "이모가 내 줄 거예요" 같은 말
_PRONOUN_HEADS = ("나", "저", "난", "전", "내가", "제가", "나는", "저는", "우리", "저희", "그냥", "아마")
# 띄어쓰기가 있는 말의 끝
_SENTENCE_ENDS = ("어", "아", "야", "지", "래", "까", "니", "냐", "네", "요", "해", "줘", "다", "음", "파", "워", "와",
                  "봐", "돼", "져", "려", "자", "라", "게", "죠", "거든", "는데", "잖아", "ㅋ", "ㅎ", "ㅠ", "ㅜ")
# 한 낱말이어도 문장인 끝 ("배고파", "몰라요", "했어요"). 명사가 거의 안 끝나는 것만
_WORD_SENTENCE_ENDS = ("파", "워", "봐", "돼", "져", "줘", "싶어", "없어", "있어", "몰라", "했어", "했다", "거든", "잖아",
                       "는데", "어요", "아요", "해요", "네요", "지요", "죠", "겠어", "었어", "았어", "였어", "했지", "할래", "갈래", "는다", "었다", "았다", "ㅋ", "ㅎ", "ㅠ", "ㅜ")
_TALK_PARTS = ("했는데", "인데", "는데 ", "해서 ", "했어", "해 줘", "해줘", "해 주세요", "해주세요", "거예요", "거에요")


def looks_sentence(message: str) -> bool:
    t = message.strip().rstrip(".!~?^ ")
    if not t:
        return False
    words = t.split()
    if len(words) == 1:
        return t.endswith(_WORD_SENTENCE_ENDS)
    return (words[0] in _PRONOUN_HEADS or t.endswith(_SENTENCE_ENDS) or any(p in t for p in _TALK_PARTS))


RETRY = {
    "name": "이름만 알려 주세요. (예: 홍길동)",
    "address": "주소를 다시 알려 주세요. 시·구·도로명과 번호까지요. (예: 서울시 OO구 OO로 12)",
    "email": "이메일 주소를 다시 알려 주세요. (예: name@example.com)",
    "bizno": "사업자등록번호(고유번호) 10자리를 알려 주세요. (예: 123-45-67890)",
}


def extract(spec: dict, message: str) -> tuple[str | None, str]:
    """(뽑은 답 또는 None, kind). text 칸은 말끝만 정리해서 돌려준다 (대화 문장인지는 부르는 쪽이 본다)"""
    kind = kind_of(spec)
    if is_noise(message) or is_noise(strip_tail(message)):  # "알아서 해 줘" 처럼 부탁만 뗀 나머지도 본다
        return None, kind
    if kind == "name":
        return _name(message), kind
    if kind == "address":
        return _address(message), kind
    if kind == "email":
        m = _EMAIL_RE.search(message)
        return (m.group(0) if m else None), kind
    if kind == "bizno":
        return _bizno(message), kind
    return strip_tail_text(message), kind


# ---------------- 칸 내용 검사 (칸별로 쓰기 · 대화로 채우기 공통) ----------------

_MASH_RE = re.compile(r"(qwer|wert|asdf|sdfg|dfgh|fghj|ghjk|hjkl|zxcv|xcvb|cvbn|vbnm|ㅁㄴㅇㄹ|ㅂㅈㄷㄱ)", re.IGNORECASE)
_REPEAT_RE = re.compile(r"(.)\1{3,}")  # 같은 글자 4번 이상 ("가가가가", "1111")
_VOWELLESS_RE = re.compile(r"^[b-df-hj-np-tv-z]{4,}$", re.IGNORECASE)  # 모음 없는 영문 ("sdkfj")
ESSAY_MIN = 10  # 자기소개 · 사유 같은 글 칸의 최소 글자 수


def looks_mash(text: str) -> bool:
    """자판을 아무렇게나 친 글자인지 ("asdf", "ㅁㄴㅇㄹ", "가가가가", "sdkfj")"""
    flat = re.sub(r"[\s.,!?~^\-]", "", text.lower())
    if not flat:
        return True
    return bool(_MASH_RE.search(flat) or _REPEAT_RE.search(flat) or _VOWELLESS_RE.match(flat))


def problem(spec: dict, value: str) -> str | None:
    """칸에 적힌 내용이 그 칸에 맞지 않으면 고칠 안내, 맞으면 None.
    이름 · 주소 · 이메일 · 사업자번호는 형식을 보고, 그 밖의 글 칸은 아무렇게나 친 글자인지 본다"""
    text = value.strip()
    if not text:
        return None
    kind = kind_of(spec)
    if kind != "name" and (is_noise(text) or looks_mash(text)):
        return "칸에 맞는 내용을 적어 주세요."
    if kind == "name":
        flat = "".join(text.split())
        if _LATIN_NAME_RE.match(text) and not looks_mash(text):
            return None
        picked = _name(text)
        # 이름만 적혀 있어야 한다 ("나는 민수" 처럼 말이 섞이면 이름만 남기게)
        ok = picked is not None and "".join(picked.split()) == flat and re.fullmatch(r"[가-힣]{2,5}", flat)
        return None if ok else "이름만 적어 주세요. (예: 홍길동)"
    if kind == "address":
        return None if _address(text) == text.strip(" .,~!") or _address(text) else RETRY["address"]
    if kind == "email":
        return None if _EMAIL_RE.fullmatch(text) else RETRY["email"]
    if kind == "bizno":
        return None if _bizno(text) else RETRY["bizno"]
    if spec.get("essay") and len("".join(text.split())) < ESSAY_MIN:
        return f"조금 더 자세히 적어 주세요. ({ESSAY_MIN}자 이상)"
    return None
