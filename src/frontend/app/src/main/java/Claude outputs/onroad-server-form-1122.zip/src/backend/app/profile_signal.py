"""대화 속 프로필 변경 감지 (상담 AI·문서 AI 공통).

"부산으로 이사했어요", "번호 010-9876-5432로 바꿨어요", "저 이번에 퇴소했어요" 처럼 프로필과 다른 값이 나오면
바꿀 후보를 돌려준다. 앱은 확인 카드를 띄우고, 사용자가 승인해야 PATCH /users/{id} 로 반영한다 (자동 반영 없음).

- 규칙으로만 찾는다. 메시지·프로필 값을 LLM 에 보내지 않는다 (api.md 1.6)
- 바뀌었다는 말(이사·바꿨·퇴소했 등)이 있을 때만 후보로 낸다. "부산 정책 알려줘" 같은 말은 후보가 아니다
"""

import re
from datetime import date

from app.codes import USER_REGIONS
from app.schemas.chat import ProfileChange
from db.models import User

STATUS_LABELS = {"in_care": "보호 중", "leaving_soon": "퇴소 예정", "left_care": "퇴소함"}
# 지금 하는 일 (앱 타임라인 개인화용). 서버에 저장하지 않고 앱이 기기에만 둔다
WORK_LABELS = {"student": "학생", "working": "일해요", "job_seeking": "일 찾는 중", "resting": "쉬는 중"}

# 지역 이름(긴 것부터) → 코드
_REGION_NAMES: list[tuple[str, str]] = sorted(
    [
        *((r, r) for r in USER_REGIONS),
        ("서울특별시", "서울"), ("서울시", "서울"), ("부산광역시", "부산"), ("부산시", "부산"),
        ("대구광역시", "대구"), ("인천광역시", "인천"), ("광주광역시", "광주"), ("대전광역시", "대전"),
        ("울산광역시", "울산"), ("세종특별자치시", "세종"), ("세종시", "세종"), ("경기도", "경기"),
        ("강원특별자치도", "강원"), ("강원도", "강원"), ("충청북도", "충북"), ("충청남도", "충남"),
        ("전북특별자치도", "전북"), ("전라북도", "전북"), ("전라남도", "전남"), ("경상북도", "경북"),
        ("경상남도", "경남"), ("제주특별자치도", "제주"), ("제주도", "제주"),
    ],
    key=lambda x: -len(x[0]),
)
_MOVE_WORDS = ("이사", "옮겼", "옮기게", "이전했", "살게됐", "살게되", "로왔", "으로왔", "에살아", "에살고", "에서살아", "에서살고")
_PHONE_RE = re.compile(r"(01[016789])[-\s.]?(\d{3,4})[-\s.]?(\d{4})")
_PHONE_WORDS = ("번호", "바꿨", "바뀌", "바꿔", "새폰", "새로")
_LEFT_WORDS = ("퇴소했", "퇴소를했", "보호종료됐", "보호종료되었", "보호가끝났", "시설에서나왔", "시설나왔")
_LEAVING_WORDS = ("곧퇴소", "퇴소예정", "퇴소할예정", "퇴소를앞두", "퇴소앞두", "퇴소하게됐", "퇴소하게되")
# 바뀌었다는 말이 있을 때만 (앞에 나온 것이 먼저: 그만두고 학교 다녀요 → 학생)
_WORK_WORDS: list[tuple[str, tuple[str, ...]]] = [
    ("job_seeking", ("퇴사했", "그만뒀", "그만두게됐", "일을그만", "알바그만", "잘렸", "해고됐", "계약이끝났", "일자리찾고", "일찾고있", "구직중", "취업준비중", "취준중")),
    ("student", ("입학했", "복학했", "대학생이됐", "대학생이되", "학교다니게됐", "학교다니고있", "대학다니고", "학교에다녀", "학생이됐")),
    ("working", ("취업했", "입사했", "출근하게됐", "출근하기시작", "알바시작", "알바를시작", "알바하게됐", "일하게됐", "일을시작", "일시작했", "일하기시작", "직장다니")),
    ("resting", ("쉬고있어", "쉬고있는", "쉬는중", "당분간쉬", "잠깐쉬")),
]
_DATE_RE = re.compile(r"(\d{4})\s*(?:년|[.\-/])\s*(\d{1,2})\s*(?:월|[.\-/])\s*(\d{1,2})")
_NAME_WORDS = ("개명", "이름바꿨", "이름을바꿨", "이름이바뀌", "이름바뀌", "이름변경", "새이름")
# 새 이름 후보: 한글 2~4자 + (조사·말끝) + 끝 (예: "정서현으로", "정서현이야", "정서현이에요", "정서현")
_NAME_RE = re.compile(
    r"(?<![가-힣])([가-힣]{2,4}?)(?:으로|로|이라고|라고|이에요|예요|이야|야|입니다|이요|요)?(?=$|[\s.,!?~])"
)
_NOT_NAMES = {"이름", "개명", "새이름", "제이름", "내이름", "저는", "나는", "이번에", "최근에", "법원", "그래서",
              "비밀", "몰라", "모름", "없어", "없음", "그냥", "아직", "뭐야", "뭐지", "그거"}
_VERB_PARTS = ("했", "었", "았", "바꿨", "바뀌", "는데", "해서", "하고", "주세", "해줘", "줘", "할게", "됐", "개명", "이름")


def _flat(text: str) -> str:
    return re.sub(r"\s+", "", text)


def _region(message: str) -> str | None:
    """이사 간 곳. "서울에서 부산으로" 처럼 둘이면 '(으)로' 앞의 곳, 아니면 마지막에 나온 곳"""
    flat = _flat(message)
    if not any(w in flat for w in _MOVE_WORDS):
        return None
    found: list[tuple[int, str, bool]] = []  # (위치, 코드, 뒤에 '(으)로')
    taken: list[tuple[int, int]] = []
    for name, code in _REGION_NAMES:
        for m in re.finditer(re.escape(name), flat):
            s, e = m.start(), m.end()
            if any(s < te and e > ts for ts, te in taken):
                continue  # 더 긴 이름(서울특별시)에 이미 포함
            taken.append((s, e))
            found.append((s, code, flat[e:e + 2].startswith(("으로", "로"))))
    if not found:
        return None
    toward = [f for f in found if f[2]]
    return max(toward or found)[1]


def _phone(message: str) -> str | None:
    flat = _flat(message)
    m = _PHONE_RE.search(message)
    if m is None or not any(w in flat for w in _PHONE_WORDS):
        return None
    return "".join(m.groups())


def _status(message: str, current: str) -> str | None:
    flat = _flat(message)
    if current != "left_care" and any(w in flat for w in _LEFT_WORDS):
        return "left_care"
    if current == "in_care" and any(w in flat for w in _LEAVING_WORDS):
        return "leaving_soon"
    return None


def _work(message: str) -> str | None:
    """지금 하는 일이 바뀌었다는 말. 여러 개면 문장에서 마지막에 나온 것 (그만두고 학교 다녀요 → 학생)"""
    flat = _flat(message)
    hits = [(flat.rfind(w), code) for code, words in _WORK_WORDS for w in words if w in flat]
    return max(hits)[1] if hits else None


def _d_date(message: str) -> date | None:
    if "퇴소" not in message:
        return None
    m = _DATE_RE.search(message)
    if m is None:
        return None
    try:
        return date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
    except ValueError:
        return None


def _phone_label(p: str | None) -> str | None:
    if not p:
        return None
    return f"{p[:3]}-{p[3:-4]}-{p[-4:]}"


_BIRTH_WORDS = ("생일", "생년월일", "태어났", "태어난", "출생")
_MONTH_DAY_RE = re.compile(r"(\d{1,2})\s*월\s*(\d{1,2})\s*일")
_YEAR_RE = re.compile(r"(\d{4})\s*년")
_SAY_NAME_RE = re.compile(
    r"(?:제|내|저의|나의)\s*이름\s*(?:은|는|이)?\s*([가-힣]{2,4}?)(?:이에요|예요|입니다|이야|야|이고|고|이요|요|으로|로)?(?=$|[\s.,!?~])"
)
_ASK_WORDS = ("뭐", "뭔", "무엇", "모르", "알려", "어떻게", "?")


def birth_in(message: str, current: date) -> date | None:
    """생일을 말한 경우 그 날짜 ("제 생일 2008년 2월 1일이에요", "생일 2월 1일이야" → 연도는 지금 값)"""
    flat = _flat(message)
    if not any(w in flat for w in _BIRTH_WORDS):
        return None
    m = _DATE_RE.search(message)
    try:
        if m:
            return date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        md = _MONTH_DAY_RE.search(message)
        if md:
            y = _YEAR_RE.search(message)
            return date(int(y.group(1)) if y else current.year, int(md.group(1)), int(md.group(2)))
        y = _YEAR_RE.search(message)
        if y:
            return date(int(y.group(1)), current.month, current.day)
    except ValueError:
        return None
    return None


def said_name(message: str) -> str | None:
    """"제 이름은 정서현이에요" 처럼 이름을 말한 경우 (묻는 말은 빼고)"""
    if any(w in message for w in _ASK_WORDS):
        return None
    m = _SAY_NAME_RE.search(message)
    if not m:
        return None
    name = m.group(1)
    if name in _NOT_NAMES or any(v in name for v in _VERB_PARTS) or name.endswith(("다", "요", "함")):
        return None
    return name


def region_in_address(text: str) -> str | None:
    """주소 글자 속 시·도 코드 ("부산광역시 해운대구 …" → 부산)"""
    flat = _flat(text)
    for name, code in _REGION_NAMES:
        if flat.startswith(name) or flat.startswith(name.replace("특별자치", "")):
            return code
    for name, code in _REGION_NAMES:
        if len(name) >= 3 and name in flat:
            return code
    return None


def name_in(message: str) -> str | None:
    """개명·이름을 바꿨다는 말 속 새 이름 (예: "나 개명했는데 정서현으로 해 줘" → "정서현"). 말이 없으면 None"""
    if not any(w in _flat(message) for w in _NAME_WORDS):
        return None
    for m in _NAME_RE.finditer(message):
        name = m.group(1)
        if name in _NOT_NAMES or any(v in name for v in _VERB_PARTS) or name.endswith(("어", "다", "지", "요", "함")):
            continue
        return name
    return None


def detect(message: str, user: User, today: date) -> list[ProfileChange]:
    out: list[ProfileChange] = []
    name = name_in(message) or said_name(message)
    if name and name != user.name:
        out.append(ProfileChange(field="name", label="이름", current=user.name, proposed=name, proposed_label=name))
    region = _region(message)
    if region and region != user.region:
        out.append(ProfileChange(field="region", label="사는 지역", current=user.region, proposed=region,
                                 proposed_label=region))
    phone = _phone(message)
    if phone and phone != user.phone:
        out.append(ProfileChange(field="phone", label="휴대폰 번호", current=_phone_label(user.phone),
                                 proposed=phone, proposed_label=_phone_label(phone)))
    current_birth = getattr(user, "birth_date", None)
    born = birth_in(message, current_birth) if current_birth else None
    if born and born != current_birth:
        out.append(ProfileChange(field="birth_date", label="생년월일", current=user.birth_date.strftime("%Y.%m.%d"),
                                 proposed=born.isoformat(), proposed_label=born.strftime("%Y.%m.%d")))
    status = _status(message, user.status)
    if status:
        out.append(ProfileChange(field="status", label="보호 상태", current=STATUS_LABELS.get(user.status),
                                 proposed=status, proposed_label=STATUS_LABELS[status]))
    work = _work(message)
    if work:
        out.append(ProfileChange(field="work", label="지금 하는 일", current=WORK_LABELS.get(user.work),
                                 proposed=work, proposed_label=WORK_LABELS[work]))
    d = _d_date(message)
    new_status = status or user.status
    if d and new_status == "leaving_soon" and d >= today and d != user.d_date:
        out.append(ProfileChange(field="d_date", label="퇴소 예정일",
                                 current=user.d_date.strftime("%Y.%m.%d") if user.d_date else None,
                                 proposed=d.isoformat(), proposed_label=d.strftime("%Y.%m.%d")))
    return out
