"""느린 요청 로그 · Server-Timing 헤더 (app.main.slow_log)."""

import logging

import app.main as main


def test_server_timing_header(api):
    res = api.get("/api/health")
    assert res.headers["server-timing"].startswith("app;dur=")


def test_slow_request_logged_without_ids(api, db_session, monkeypatch, caplog):
    from tests.factories import make_user

    user = make_user(db_session)
    monkeypatch.setattr(main, "SLOW_MS", 0)
    with caplog.at_level(logging.WARNING, logger="app.main"):
        api.get(f"/api/users/{user.id}/dashboard")
    lines = [r.getMessage() for r in caplog.records if "느린 요청" in r.getMessage()]
    assert lines and "{user_id}" in lines[0] and str(user.id) not in lines[0]


def test_health_not_logged(api, monkeypatch, caplog):
    monkeypatch.setattr(main, "SLOW_MS", 0)
    with caplog.at_level(logging.WARNING, logger="app.main"):
        api.get("/api/health")
    assert not [r for r in caplog.records if "느린 요청" in r.getMessage()]
